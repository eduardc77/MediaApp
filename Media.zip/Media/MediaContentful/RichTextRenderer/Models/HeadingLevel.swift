
public enum HeadingLevel: Int {
    case h1 = 1
    case h2
    case h3
    case h4
    case h5
    case h6
}
