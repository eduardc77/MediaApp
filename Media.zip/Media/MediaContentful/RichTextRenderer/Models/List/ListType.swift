
/// Represents type of a list.
public enum ListType {
    case ordered
    case unordered
}
