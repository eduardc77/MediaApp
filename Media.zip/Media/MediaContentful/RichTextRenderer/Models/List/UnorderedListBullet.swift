
enum UnorderedListBullet: String {
    case fullCircle = "•"
    case emptyCircle = "◦"
    case fullSquare = "▪︎"
}
