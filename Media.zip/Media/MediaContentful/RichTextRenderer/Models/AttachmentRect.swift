
import CoreGraphics

struct AttachmentAttributes {
    let boundingRect: CGRect
    let lineFragmentRect: CGRect
}
