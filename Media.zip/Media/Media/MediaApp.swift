//
//  MediaApp.swift
//  Media
//

import SwiftUI

@main
struct MediaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
