
public struct DemoAPIKeys {
    public static let newsAPIKey = "66a9e1366c644e829c403ecfe0ff518f"
    public static let theMovieDB = "c9237ef2809ed01e64d7b37b0f951c7b"
}
